package com.edge.graphQL;

import graphql.GraphQL;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import io.micronaut.context.annotation.Bean;
import io.micronaut.context.annotation.Factory;
import io.reactivex.Single;
import io.reactivex.disposables.Disposable;

import javax.inject.Inject;
import javax.inject.Singleton;

import com.edge.graphQL.datafetcher.AllUserDataFetcher;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

/**
 * Factory used to configure the GraphQL schema and wire up the data fetchers.
 */
@Factory
public class GraphQLFactory {

    // wire up all marked data fetchers
	@Inject
	private AllUserDataFetcher alluserDataFetcher;

    public GraphQLFactory() {
        super();
    }

    @Bean
    @Singleton
    public GraphQL graphQL() {
    	   File schemaFile = new File("graphql.schema");
    	  // parse scheql
    	  TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(schemaFile);
    	  RuntimeWiring wiring =  RuntimeWiring.newRuntimeWiring().type("Query", typeWiring -> typeWiring
    			   .dataFetcher("users", alluserDataFetcher)).build();
    	  GraphQLSchema schema = new SchemaGenerator().makeExecutableSchema(typeRegistry, wiring);
    	 GraphQL graphQL = GraphQL.newGraphQL(schema).build();
    	 return graphQL;
    }

   
   
    
}

package com.edge.graphQL.datafetcher;

import java.util.List;

import javax.inject.Inject;

import com.edge.cache.GraphCacheRepo;
import com.edge.pojo.User;
import com.edge.service.GraphCacheService;

import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class AllUserDataFetcher implements DataFetcher < List < User >> {

	@Inject
	GraphCacheRepo cache;
	@Override
	public List<User> get(DataFetchingEnvironment environment) {
		// TODO Auto-generated method stub
		System.out.println("Inside datafetcher");
		return cache.fetchAll();
	}

}

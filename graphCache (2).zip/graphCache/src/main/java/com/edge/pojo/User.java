package com.edge.pojo;

import java.util.List;

public class User {

		private String pan;
		private String name;
		private String ph;
		private List<Account> accounts;
		private List<Payee> payees;
		public String getPan() {
			return pan;
		}
		public void setPan(String pan) {
			this.pan = pan;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPh() {
			return ph;
		}
		public void setPh(String ph) {
			this.ph = ph;
		}
		public List<Account> getAccounts() {
			return accounts;
		}
		public void setAccounts(List<Account> accounts) {
			this.accounts = accounts;
		}
		public List<Payee> getPayees() {
			return payees;
		}
		public void setPayees(List<Payee> payees) {
			this.payees = payees;
		}
		public User(String pan, String name, String ph, List<Account> accounts, List<Payee> payees) {
			super();
			this.pan = pan;
			this.name = name;
			this.ph = ph;
			this.accounts = accounts;
			this.payees = payees;
		}
		public User(){
			
		}
		
}

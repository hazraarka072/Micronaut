package com.edge.pojo;

public class Account {
	private String accountId;
	private String type;
	private int balance;
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Account(String accountId, String type, int balance) {
		super();
		this.accountId = accountId;
		this.type = type;
		this.balance = balance;
	}
	
}

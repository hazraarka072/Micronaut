package com.edge;

import java.util.List;

import com.edge.cache.GraphCacheRepo;
import com.edge.pojo.User;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GraphCacheRepo repo=new GraphCacheRepo();
		
		List<User> l=repo.fetchAll();
	}

}

package com.edge.cache;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Singleton;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.ResourceIterator;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;

import com.edge.pojo.Account;
import com.edge.pojo.Payee;
import com.edge.pojo.User;
import com.edge.service.util.Relations;

@Singleton
public class GraphCacheRepo {

	private GraphDatabaseService graphCache;

	public GraphCacheRepo() {
		GraphDatabaseFactory graphDbFactory = new GraphDatabaseFactory();
		graphCache=graphDbFactory.newEmbeddedDatabase(
				  new File("data/graph"));
		
		String contents="";
		try {
			contents = new String(Files.readAllBytes(Paths.get("data.txt")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		Transaction tx=graphCache.beginTx();
		graphCache.execute(contents);
		tx.success();
	}
	
	public List<User> fetchAll(){
		/*User u=new User("a","b","c",null,null);
		return Arrays.asList(u);*/
		List<User> result= new ArrayList<User>();
		Label label = Label.label( "USER" );
		System.out.println("insidegraphcache repo");
        String nameToFind = "Arka";
		try ( Transaction tx = graphCache.beginTx() )
        {
            try ( ResourceIterator<Node> users =
                          graphCache.findNodes(label) )
            {
            	
                ArrayList<Node> userNodes = new ArrayList<>();
                while ( users.hasNext() )
                {
                    userNodes.add( users.next() );
                }

                for ( Node node : userNodes )
                {
                    User u= new User();
                    u.setName((String) node.getProperty("name"));
                    u.setPan((String) node.getProperty("pan"));
                    u.setPh((String) node.getProperty("phone"));
                    List<Account> accounts=new ArrayList<Account>();
                    List<Payee> payees=new ArrayList<Payee>();
                    Iterable<Relationship> accountsRel=node.getRelationships(Relations.HAS);
                    for(Relationship ref:accountsRel){
                    	Node accountNode=ref.getEndNode();
                    	System.out.println((String)accountNode.getProperty("type"));
                    	String id=(String)accountNode.getProperty("id");
                    	String type=(String)accountNode.getProperty("type");
                    	int bal;
                    	try{
                    	bal =Integer.parseInt((String) accountNode.getProperty("Bal"));
                    	}catch(org.neo4j.graphdb.NotFoundException e){
                    		bal =Integer.parseInt((String) accountNode.getProperty("limit"));
                    	}
                    	Account acc=new Account(id,type,bal);
                    	accounts.add(acc);
                    
                    }
                    u.setAccounts(accounts);
                    
                    Iterable<Relationship> payeeRel=node.getRelationships(Relations.PAYS);
                    
                    for(Relationship ref:payeeRel){
                    	Node payeeNode=ref.getEndNode();
                    	
                    	String name=(String)payeeNode.getProperty("name");
                    	String accountId=(String)payeeNode.getProperty("account_id");
                    	
                    	Payee pye=new Payee(name,accountId);
                    	payees.add(pye);
                    
                    }
                    u.setPayees(payees);
                    
                    
                    
                    result.add(u);
                }
            }
        }
		return result;
		
	}
	
	
}

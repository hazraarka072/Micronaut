package com.edge.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.validation.constraints.Size;

import com.edge.pojo.User;
import com.edge.service.GraphCacheService;
import com.edge.graphQL.GraphQLQuery;

import graphql.ExecutionResult;
import graphql.GraphQL;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;

@Controller("/") 
public class CacheController {

	@Inject
	GraphCacheService cacheService;
	@Inject
	GraphQL graphQL;
	
	@Get("/user")
	List<User> getUsers(){
		return cacheService.getuserDetails();
		
		
		
	}
	
	@Post(value="/userGraph", consumes=MediaType.APPLICATION_JSON)
    public Map<String, Object> graphqlPost(@Size(max=4096) @Body GraphQLQuery query) {
		System.out.println("Inside graph controller");

        // execute the query
        ExecutionResult executionResult = graphQL.execute(query.getQuery());

        // build the resulting response
        Map<String, Object> result = new HashMap<>();
        result.put("data", executionResult.getData());
		System.out.println(result.get("data"));


        // append any errors that may have occurred
        List<?> errors = executionResult.getErrors();
        if (errors != null && !errors.isEmpty()) {
            result.put("errors", errors);
        }

        // add any extension data
        result.put("exentions", executionResult.getExtensions());

        // return the resulting data
        return result;
    }
	
	
}

package com.edge.service;

import java.util.List;

import javax.inject.Inject;

import com.edge.cache.GraphCacheRepo;
import com.edge.pojo.User;

public interface GraphCacheService {
	
	public List<User> getuserDetails();
}

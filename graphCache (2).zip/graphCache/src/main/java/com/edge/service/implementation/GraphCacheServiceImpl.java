package com.edge.service.implementation;

import java.util.List;

import javax.inject.Inject;

import com.edge.cache.GraphCacheRepo;
import com.edge.pojo.User;
import com.edge.service.GraphCacheService;

public class GraphCacheServiceImpl implements GraphCacheService{

	@Inject
	GraphCacheRepo cache;
	
	@Override
	public List<User> getuserDetails() {
		// TODO Auto-generated method stub
		return cache.fetchAll();
	}

}

package com.edge.service.util;

import org.neo4j.graphdb.RelationshipType;

public enum Relations implements RelationshipType {
	HAS,
	LINKED_TO,
	PAYS
}

package com.edge.pojo;

public class Payee {

	private String name;
	private String accountId;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public Payee(String name, String accountId) {
		super();
		this.name = name;
		this.accountId = accountId;
	}
	
}

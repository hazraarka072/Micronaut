package com.edge.cache;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Singleton;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.ResourceIterator;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;

import com.edge.pojo.User;
import com.edge.service.util.Relations;

@Singleton
public class GraphCacheRepo {

	private GraphDatabaseService graphCache;

	public GraphCacheRepo() {
		GraphDatabaseFactory graphDbFactory = new GraphDatabaseFactory();
		graphCache=graphDbFactory.newEmbeddedDatabase(
				  new File("data/graph"));
		
		String contents="";
		try {
			contents = new String(Files.readAllBytes(Paths.get("data.txt")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		Transaction tx=graphCache.beginTx();
		graphCache.execute(contents);
		tx.success();
	}
	
	public List<User> fetchAll(){
		/*User u=new User("a","b","c",null,null);
		return Arrays.asList(u);*/
		List<User> result= new ArrayList<User>();
		Label label = Label.label( "USER" );
        
        String nameToFind = "Arka";
		try ( Transaction tx = graphCache.beginTx() )
        {
            try ( ResourceIterator<Node> users =
                          graphCache.findNodes(label) )
            {
            	
                ArrayList<Node> userNodes = new ArrayList<>();
                while ( users.hasNext() )
                {
                    userNodes.add( users.next() );
                }

                for ( Node node : userNodes )
                {
                    User u= new User();
                    u.setName((String) node.getProperty("name"));
                    u.setPan((String) node.getProperty("pan"));
                    u.setPh((String) node.getProperty("phone"));
                    //ResourceIterator<Node> accounts=node.getRelationships(Relations.HAS)
                    result.add(u);
                }
            }
        }
		return result;
		
	}
	
	
}

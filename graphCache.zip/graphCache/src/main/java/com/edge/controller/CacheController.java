package com.edge.controller;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import com.edge.pojo.User;
import com.edge.service.GraphCacheService;

import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;

@Controller("/") 
public class CacheController {

	@Inject
	GraphCacheService cacheService;
	
	@Get("/user")
	List<User> getUsers(){
		return cacheService.getuserDetails();
		
		
		
	}
	
}
